<?php
require "./lib.php";
$get = "https://www.askdaraz.com/?ref=zeldin26";
echo ">> LIST : "; $list = trim(fgets(STDIN));
if(!is_file($list) && !file_exists($list)){
    die("HTTPS PROXIES NOT FOUND!\n");
}
while(1){
    $explode = explode("\n", file_get_contents($list));
    $uagent = RandUagent();
    $proxy = $explode[array_rand($explode)];
    $curl = curl($get, 0, 0, $proxy, $uagent);
    $email = getRandName()['mail'];
    $cookie = fetchCookies($curl[0]);
    $regis = "https://www.askdaraz.com/requests.php?f=register";
    $query = http_build_query(array(
        "username" => generateRandomString(5).rand(1,20),
        "email" => $email,
        "password" => "Zazterin312~",
        "confirm_password" => "Zazterin312~",
        "gender" => "male",
        "accept_terms" => "on"
        )
    );
    $header = array();
    $header[] = "User-Agent: ".$uagent;
    $header[] = "Accept: */*";
    $header[] = "Accept-Language: id,en-US;q=0.7,en;q=0.3";
    $header[] = "Referer: https://www.askdaraz.com/register";
    $header[] = "Content-Type: application/x-www-form-urlencoded; charset=UTF-8";
    $header[] = "X-Requested-With: XMLHttpRequest";
    $header[] = "Connection: keep-alive";
    $header[] = "Cookie: PHPSESSID=".$cookie['PHPSESSID']."; ad-con=".$cookie['ad-con']."; _us=".$cookie['_us']."; mode=".$cookie['mode']."; access=1; src=1; humans_21909=1; cookieconsent_status=dismiss";
    $data = curl($regis, $query, $header, $proxy, $uagent);
    if(preg_match("/Successfully joined/i", $data[1])){
        echo "{~} Success Register => ".$email."\n";
    }else{
        echo "{!} Failed Register => ".$email."\n"; 
    }
}
?>